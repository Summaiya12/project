<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
<input type="file" name="img" required ><br><br>
<input type="submit" name="btn" value="Submit">

    </form>









<?php

// $con =mysqli_connect("localhost","root","","m") or die("sdafs");

// if (isset($_POST['btn'])) {
//     $img=$_FILES['img'] ;
  
//     if($img["type"] == "image/jpg" || $img["type"] == "image/png" || $img["type"] == "image/jpeg"){
// $pic= move_uploaded_file($img["tmp_name"],"img/".$img["name"]);

//     }


//     else {
    
//         echo "Only image uploaded";
        
//         }





// // $qu = mysqli_query($con,"insert into img values('','$pic')");
// // if ($qu,) {
// // echo "done";
// // }
// // else {
// //     echo "Not found";
// // }
    



// }
?>


<?php


  
  // If upload button is clicked ...
  if (isset($_POST['btn'])) {
  
    $filename = $_FILES["img"]["name"];
    $tempname = $_FILES["img"]["tmp_name"];    
        $folder = "img/".$filename;
          
    $db = mysqli_connect("localhost", "root", "", "m");
  
        // Get all the submitted data from the form
        $sql = "INSERT INTO img  VALUES ('','$filename')";
  
        // Execute query
     $qu=   mysqli_query($db, $sql);
          
        // Now let's move the uploaded image into the folder: image
     if ($qu) {
        if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
        }else{
            $msg = "Failed to upload image";
      }    
    
    
    
    } else {
       echo "not uploaded";
     }
     
  }
?>



</body>
</html>