-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2022 at 11:19 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reg`
--

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Cpassword` varchar(50) NOT NULL,
  `Token` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`Id`, `Name`, `Email`, `Password`, `Cpassword`, `Token`, `Status`) VALUES
(1, 'SAADZI', 'saadzgaming1812871@gmail.com', '$2y$10$nRiLSl3KRVLOVcVAXZFmXef89AOmhlUiyc1Y8C9pm39', '$2y$10$zLW5bcaWAFsQs7I26tL5oO6cqHy1bFNpe36U0su7CBZ', 'd4b5c745b5efda6d7ae4f0a4d53860', 'inactive'),
(2, 'SAADZI', 'nimraaslam7869@gmail.com', '$2y$10$g7jrtEoDCfcXiwX8yoY1/urElPTeXaaPqQmfG6f8q7i', '$2y$10$Xt87V/8lekzveSpJEuhOw.DKSo2lNPxTe/kcAqPyxd0', 'c2ab5d791cdfe75e160296a8d54862', 'inactive'),
(3, 'Ariyan Balaaj', 'shapaatar69@gmail.com', '$2y$10$gQ.oWnQU7Sl5kiMgRIo1b.rgptlHNcQTL88eYcInoxl', '$2y$10$TqA80GCssiDrkzpvlAmW1efZJRr5OvMh46sB16aW5.v', '1f4b0c95e49f6c2c83a5ccfff2fe09', 'inactive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
