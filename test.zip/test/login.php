<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <form method="POST">
    <input type="email" name="email" value="">    <br><br>
<input type="password" name="password" value=""><br><br>
<input type="submit"  name="btn" value="zc">
    </form>

<?php
include 'connection.php';
if(isset($_POST['btn']))
{
    $email=$_POST['email'];
$pass= $_POST['password']; 
$emailquery = mysqli_query($con,"select * from log where Email='$email'");
$emailcount = mysqli_num_rows($emailquery);
$con = mysqli_connect("localhost","root","","reg") or die("sdfgdf");

if ($emailcount) {
  $email_pass = mysqli_fetch_assoc($emailquery);


  $dbpass=$email_pass['Password'];
$decode= password_verify($pass,$dbpass);
if ($decode) {
echo "loged In";
header("location: logout.php");

} else {
echo "inncorrect password";
}

} else {
  echo "Incorect Email";
    
}









}




?>

    </body>
</html>