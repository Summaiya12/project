<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <form method="POST">
    <label for="">Name: </label> 
    <input type="text" name="name" value=""><br><br>

    <label for="">Email: </label>
<input type="email" name="email" value=""><br><br>

<label for="">Password: </label>
<input type="password" name="pass" value=""><br><br>

<label for="">Confirm Password: </label>
<input type="password" name="cpass" value="">

<br><br><br>
<input type="submit" name="btn" value="Create Account" style="margin-left:50px">
    </form>

<?php
include 'connection.php';
if (isset($_POST['btn'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = $_POST['pass'];
  $cpass = $_POST['cpass']  ;

  $pas=password_hash($pass, PASSWORD_BCRYPT);
  $cpas=password_hash($cpass, PASSWORD_BCRYPT);
 
  
  $emailquery = mysqli_query($con,"select * from log where Email='$email'");
  $emailcount = mysqli_num_rows($emailquery);


  if ($emailcount>0) {
      ?>
<div>
    <p style="background-color: red;">Email Is Already Exist</p>
  </div>


<?php



  } else {if ($pass === $cpass)                           {
  

        $qu = mysqli_query($con, "insert into log values('','$name','$email','$pas','$cpas')");
    
    
    
        echo "You Successfully created your Account";      }
    
    
    else    {
        echo "<script>
        alert('Passsword are not matched')
    </script>";
             }




  }}
?>
    </body>
</html>